import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';

const app = express();

// миддлвары
app.use(cors());
app.use(express.json());

// подключение к локальной MongoDB
const mongoUrl = 'mongodb://localhost:27017/mydatabase';
mongoose.connect(mongoUrl);

mongoose.connection.on('open', () => {
    console.log('Mongo DB is connected');
});
mongoose.connection.on('error', (err) => {
    console.log('Mongo DB is failed', err);
});

// простой health-check
app.get('/health', (req, res) => {
    res.json({ ok: true });
});

app.listen(5555, () => {
    console.log('Server started at 5555');
});
